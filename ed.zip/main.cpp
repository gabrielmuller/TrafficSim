//#include <iostream>
#include <simple_time.h>
#include <random.h>
#include <Car.cpp>
#include <Lane.cpp>
#include <Event.cpp>
#include <Clock.cpp>
int main(int argc, char* argv[]) {
	using namespace utility;

	std::cout << "AAAAAAAAAAAAAAAAAAA" << '\n';

	return 0;
}
