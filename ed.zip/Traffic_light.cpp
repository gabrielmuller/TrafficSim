#ifndef TRAFFIC_LIGHT_CPP_
#define TRAFFIC_LIGHT_CPP_

#include "array_list.h"

enum direction {NORTH = 0, SOUTH = 1, EAST = 2, WEST = 3};

class Traffic_light {
private:
	static direction direction_;

public:

	static direction direction() {
		return direction_;
	}

	static void changeDirection() {
		switch(direction_) {
			case NORTH: direction_ = EAST; break;
			case EAST: direction_ = SOUTH; break;
			case SOUTH: direction_ = WEST; break;
			case WEST: direction_ = NORTH; break;
		}
	}

};

#endif
