#ifndef EVENT_CPP_
#define EVENT_CPP_

#include <sstream>
#include "Lane.cpp"
#include "Car.cpp"
#include "Traffic_light.cpp"
#include "simple_time.h"
/** Usado como valor nulo para structs
 *
 */
struct nothing{};

/** Enumera��o dos tipos de evento
 *
 */
enum event_type {car_enter_lane = 0, car_enter_queue = 1, light_switch = 2};
/** Struct dos poss�veis tipos de info adicional
 *
 */
struct extra_info {
	/** Caso car_enter_lane
	 * from -> pista origem (nullptr se carro surgiu)
	 * to -> pista destino (nullptr se carro sumiu)
	 * Caso car_enter_queue
	 * from = to = pista do carro
	 */
	Lane* from;
	Lane* to;

	extra_info() {
		from = nullptr;
		to = nullptr;
	}
};

/** Objeto participando do evento
 *
 */

static const std::string dir_names[4] = {"sul", "leste", "oeste", "norte"}; /**< nome do prox */

class Event {
private:
	event_type event_; /**< tipo do evento */
	utility::Simple_time time_; /**< tempo em que o evento ocorreu */

	Car* car_; /**< carro que participa do evento */
	extra_info extra_; /**< informa��o adicional */



public:
	/** Construtor no caso car_enter_lane
	 *	\param time tempo do evento
	 *	\param car carro
	 *	\param from pista origem
	 *	\param to pista destino
	 */
	Event (utility::Simple_time time, Car* car, Lane* from, Lane* to) {
		event_ = car_enter_lane;
		time_ = time;
		car_ = car;
		extra_ = *(new extra_info());
		extra_.from = from;
		extra_.to = to;
	}

	/** Construtor no caso car_enter_queue
	 *  \param time tempo do evento
	 *  \param car carro
	 *  \param current pista atual do carro
	 */
	Event (utility::Simple_time time, Car* car, Lane* current) {
		event_ = car_enter_queue;
		time_ = time;
		car_ = car;
		extra_ = *(new extra_info());
		extra_.from = current;
		extra_.to = current;
	}

	/** Construtor no caso light_switch
	 *  \param time tempo do evento
	 */
	Event (utility::Simple_time time) {
		event_ = light_switch;
		time_ = time;

	}

	/** Um evento aconteceu antes do outro?
	 *  \return true se lado esquerdo aconteceu antes do direito
	 */
	bool operator< (const Event other) const {
		return time_ < other.time_;
	}

	/** Representa��o em string do evento.
	 *
	 */
	std::string to_string () {
		std::ostringstream output;
		std::string parts[7];
		output << time_.to_string() << " ";

		switch (event_) {
		case (car_enter_lane):
		{
			std::string from_str, to_str;
			if (extra_.from == nullptr) {
				from_str = "o nada";
			} else {
				from_str = "a pista " + extra_.from->name();
			}
			if (extra_.to == nullptr) {
				to_str = "o nada";
			} else {
				to_str = "a pista " + extra_.to->name();
			}
			output << "Carro " << car_->name() << " vindo d"
					<< from_str << " foi para " << to_str << ".";
			break;
		}
		case (car_enter_queue):
		{
			output << "Carro " << car_->name() << " entrou na sua fila " << extra_.from->name() << ".";
			break;
		}
		case (light_switch):
		{
			output << "Sem�foro mudou a dire��o para " << dir_names[int (Traffic_light::direction())] << ".";
			break;
		}
		default:
		{
			throw "Tipo inv�lido de evento";
			break;
		}
		}
		return output.str();
	}

	/** Realiza o evento.
	 *
	 */
	void run () {
		switch (event_) {
		{
		case (car_enter_lane):
			if (extra_.from != nullptr) { //se n�o foi spawn
				extra_.from->removeCar();
			}
			if (extra_.to == nullptr) { //se despawn
				delete car_;
			} else {
				extra_.to->addCar(car_);
			}
		break;
		}
		case (car_enter_queue):
		{
			extra_.to->pushCar(car_);
			break;
		}
		case (light_switch):
		{
			Traffic_light::changeDirection();
		}
		default:
		{
		throw "Tipo inv�lido de evento";
		}
		}
	}

	utility::Simple_time get_time () {
		return time_;
	}
};

#endif
