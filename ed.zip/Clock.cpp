#ifndef CLOCK_CPP_
#define CLOCK_CPP_

#include "linked_list.h"
#include <iostream>
#include <sstream>
#include <Event.cpp>
#include <simple_time.h>

class Clock {
public:

	/** Lista de eventos a serem executados como string
	 *  para debug
	 */
	static std::string to_string() {
		std::ostringstream output;
		output << "Lista de eventos:\n---------------------------\n" << events.to_string();
		return output.str();
	}

	/** Adiciona evento cronologicamente.
	 * 	\param event evento a ser adicionado.
	 */
	static void push(Event event) {
		events.insert_sorted(event);
	}

	/** Anda um passo no rel�gio.
	 *
	 */
	static void step() {
		Event step = events.pop_back();
		std::cout << step.to_string() << std::endl;
		step.run();
		time_ = step.get_time();
		delete &step;
	}

	static utility::Simple_time get_time() {
		return time_;
	}
private:
	static structures::LinkedList<Event> events;
	static utility::Simple_time time_;
};
#endif
