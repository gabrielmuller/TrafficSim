#ifndef CAR_CPP_
#define CAR_CPP_

#include <cstdlib>
#include <string>
#include "simple_time.h"

class Car {

private:
	int size_;  /**< Tamanho do carro. Varia de 2 a 6m, mais 3m entre carros */
	double distance_to_light;
	utility::Simple_time last_update;

public:
	Car() {
		size_ = 5 + 4 * (rand() / RAND_MAX);
	}

	int size() {
		return size_;
	}

	std::string name() {
		return "Relampogos McDonalds";
	}
};

#endif
