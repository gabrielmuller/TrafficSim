#ifndef LANE_CPP_
#define LANE_CPP_

#include "Car.cpp"
#include "linked_queue.h"
#include "random.h"
#include "Traffic_light.cpp"

class Lane {
protected:

	direction direction_;
	int* probabilities_;  				// [0] left, [1] straight, [2] right
	int velocity_, size_, freeSpace_;

	int totalIn_ = 0, totalOut_ = 0;
	structures::LinkedQueue<Car*> moving_queue, waiting_queue;
	Lane *rightExit, *straightExit, *leftExit;

	int choose_lane() {
		int r = utility::random_range(0, 100);
		int output;
		if (r < probabilities_[0]) {
			output = 0;
		} else if (r < probabilities_[0] + probabilities_[1]) {
			output = 1;
		} else {
			output = 2;
		}
		return output;
	}
public:
	Lane(direction dir, int* prob, int vel, int size):
			direction_(dir),
			probabilities_(prob),
			velocity_(vel),
			size_(size),
			freeSpace_(size),
			rightExit(nullptr),
			straightExit(nullptr),
			leftExit(nullptr)
		{}

	Lane(direction dir, int* prob, int vel, int size, Lane* r, Lane* s, Lane* l):
		direction_(dir),
		probabilities_(prob),
		velocity_(vel),
		size_(size),
		freeSpace_(size),
		rightExit(r),
		straightExit(s),
		leftExit(l)
	{}

	void addCar(Car* car) {
		if (car->size() < freeSpace_) {
			throw std::runtime_error("Full lane");
		}

		moving_queue.enqueue(car);
		++totalIn_;
	}

	void pushCar() {
		Car* car =  moving_queue.dequeue();
		waiting_queue.enqueue(car);
		freeSpace_ -= car->size();

	}
	Car* removeCar() {
		Car* car = waiting_queue.dequeue();
		freeSpace_ += car->size();
		++totalOut_;
		return car;
	}

	Car* frontCar() {
		return waiting_queue.front();
	}
	bool empty() {
		return moving_queue.empty();
	}

	std::string name() {
		return "copa pist�o";
	}

	int timeTaken() {
		return size_ / velocity_ / 3.6;
	}

	Lane* moveCar(Lane* exit) {
		if (Traffic_light::direction() != direction_) {
			throw std::runtime_error("Sinal vermelho");
		}
		Car* car = removeCar();
		exit->addCar(car);
	}
};

class Spawn : public Lane {
private:
	int fixedFreq, varFreq;
public:
	Spawn(direction dir, int* prob, int vel, int size, int ff, int vf, Lane* r, Lane* s, Lane* l):
		Lane(dir, prob, vel, size, r, s, l),
		fixedFreq(ff - vf), varFreq(2*vf)
	{}

	void createCar() {
		Car* car;
		addCar(car);
	}

	/*Lane* moveCar() {
		if (Traffic_light::direction() != direction_) {
			throw std::runtime_error("Sinal vermelho");
		}

		auto car = frontCar();

		int r = utility::random_range(0, 100);

		if (r < probabilities_[0]) {
			leftExit->addCar(car);
			return leftExit;
		} else if (r < probabilities_[0] + probabilities_[1]) {
			rightExit->addCar(car);
			return rightExit;
		} else {
			straightExit->addCar(car);
			return straightExit;
		}
	}*/

	int timeForNewCar() {
		return fixedFreq + varFreq*utility::random_value();
	}
};

/*
 * Central � s� uma Lane normal?
 * class CentralLane : public Lane {
private:
	Lane *rightExit, *straightExit, *leftExit;
public:
	CentralLane(direction dir, int* prob, int vel, int size, Lane* r, Lane* s, Lane* l):
		Lane(dir, prob, vel, size, r, s, l),
		rightExit(r), straightExit(s), leftExit(l)
	{}

	Lane* moveCar() {
		if (Traffic_light::direction() != direction_) {
			throw std::runtime_error("Sinal vermelho");
		}

		auto car = removeCar();

		int r = utility::random_range(0, 100);

		if (r < probabilities_[0]) {
			leftExit->addCar(car);
			return leftExit;
		} else if (r < probabilities_[0] + probabilities_[1]) {
			rightExit->addCar(car);
			return rightExit;
		} else {
			straightExit->addCar(car);
			return straightExit;
		}
	}
};*/

class Edge : public Lane {
public:
	Edge(direction dir, int* prob, int vel, int size):
		Lane(dir, prob, vel, size)
	{}

	void moveCar() {
		Car* car = removeCar();
		delete car;
	}
};

#endif
