#ifndef EVENT_H_
#define EVENT_H_

#include <sstream>
#include <iostream>
#include "Lane.cpp"
#include "Car.cpp"
#include "Traffic_light.h"
#include "simple_time.h"
#include "linked_list.h"

/** Usado como valor nulo para structs
 *
 */
struct nothing {
};

/** Enumera��o dos tipos de evento
 *
 */
enum event_type {
	car_enter_lane = 0, car_enter_queue = 1, light_switch = 2
};
/** Struct dos poss�veis tipos de info adicional
 *
 */
struct extra_info {
	/** Caso car_enter_lane
	 * from -> pista origem (nullptr se carro surgiu)
	 * to -> pista destino (nullptr se carro sumiu)
	 * Caso car_enter_queue
	 * from = to = pista do carro
	 */
	Lane* from;
	Lane* to;

	extra_info() {
		from = nullptr;
		to = nullptr;
	}
};

/** Objeto participando do evento
 *
 */

static const std::string dir_names[4];

class Event {
private:
	event_type event_; /**< tipo do evento */
	utility::Simple_time time_; /**< tempo em que o evento ocorreu */

	Car* car_; /**< carro que participa do evento */
	extra_info extra_; /**< informa��o adicional */

	static structures::LinkedList<Event*> events;
	static utility::Simple_time clock_time_;

public:
	/** Construtor no caso car_enter_lane
	 *	\param time tempo do evento
	 *	\param car carro
	 *	\param from pista origem
	 *	\param to pista destino
	 */
	Event(utility::Simple_time time, Car* car, Lane* from, Lane* to);

	/** Construtor no caso car_enter_queue
	 *  \param time tempo do evento
	 *  \param car carro
	 *  \param current pista atual do carro
	 */
	Event(utility::Simple_time time, Lane* current);

	/** Construtor no caso light_switch
	 *  \param time tempo do evento
	 */
	Event(utility::Simple_time time);

	/** Um evento aconteceu antes do outro?
	 *  \return true se lado esquerdo aconteceu antes do direito
	 */
	bool operator<(const Event other) const;

	/** Representa��o em string do evento.
	 *
	 */
	std::string to_string();

	/** Realiza o evento.
	 *
	 */
	std::string run();

	utility::Simple_time get_time();


	/*------REL�GIO------*/

	/** Lista de eventos a serem executados como string
	 *  para debug
	 */
	static std::string clock_to_string();

	/** Adiciona evento cronologicamente.
	 * 	\param event evento a ser adicionado.
	 */
	static void push(Event* event);

	/** Anda um passo no rel�gio.
	 *
	 */
	static void step();

	static utility::Simple_time clock_get_time();
};

#endif
