#include <iostream>
#include <unistd.h>
#include "random.h"
#include "Car.cpp"
#include "Lane.cpp"
#include "event.h"

int main(int argc, char* argv[]) {
    using namespace utility;

    std::cout << "meu deus compilou!!!!!!!!!!!" << '\n';

    // Sumidouros semaforo 1
    int e[3] = {0,0,0};
    Edge *O1oeste = new Edge(WEST, e, 80, 2000);
    Edge *N1norte = new Edge(NORTH, e, 60, 500);
    Edge *S1sul = new Edge(SOUTH, e, 60, 500);

    // Sumidouros semaforo 2
    Edge *L1leste = new Edge(EAST, e, 40, 400);
    Edge *N2norte = new Edge(NORTH, e, 40, 500);
    Edge *S2sul = new Edge(SOUTH, e, 40, 500);

    // Pistas Centrais
    int c1[3] = {30, 40, 30};
    int c2[3] = {30, 40, 30};
    Lane *C1oeste = new Lane(WEST, c1, 60, 300, N1norte, O1oeste, S1sul);
    Lane *C1leste = new Lane(EAST, c2, 60, 300, S2sul, L1leste, N2norte);

    // Fontes semaforo 1
    int s1[3] = {10, 10, 80};
    int s2[3] = {10, 80, 10};
    int s3[3] = {80, 10, 80};
    Spawn *N1sul = new Spawn(SOUTH, s1, 60, 500, 20, 5, O1oeste, S1sul ,C1leste);
    Spawn *O1leste = new Spawn(EAST, s2, 80, 2000, 10, 2, S1sul, C1leste, N1norte);
    Spawn *S1norte = new Spawn(NORTH, s3, 60, 500, 30, 7, C1leste, N1norte, O1oeste);

    // Fontes semaforo 2
    int s4[3] = {40, 30, 30};
    int s5[3] = {30, 30, 40};
    int s6[3] = {40, 30, 30};
    Spawn *S2norte = new Spawn(NORTH, s4, 40, 500, 60, 15, L1leste, N2norte, C1oeste);
    Spawn *N2sul = new Spawn(SOUTH, s5, 40, 500, 60, 15, C1oeste, S2sul, L1leste);
    Spawn *L1oeste = new Spawn(WEST, s6, 40, 500, 60, 15, N2norte, C1oeste, S2sul);

    Spawn* spawns[6] = {N1sul, O1leste, S1norte, S2norte, N2sul, L1oeste};
    for (int i = 0; i < 6; i++) {
    	utility::Simple_time t = *(new utility::Simple_time(i*1000));
    	Event* startSpawn = new Event(t, nullptr, nullptr, spawns[i]);
    	Event::push(startSpawn);
    }
    for(int i = 0; i < 7; i++) {
    	Event::step();
    }
    std::cout << Event::clock_to_string();
    return 0;
}
