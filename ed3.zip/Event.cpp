#ifndef EVENT_CPP_
#define EVENT_CPP_

#include "event.h"

	structures::LinkedList<Event*> Event::events = *(new structures::LinkedList<Event*>());
	utility::Simple_time Event::clock_time_ = *(new utility::Simple_time());

	/** Construtor no caso car_enter_lane
	 *	\param time tempo do evento
	 *	\param car carro
	 *	\param from pista origem
	 *	\param to pista destino
	 */
	Event::Event (utility::Simple_time time, Car* car, Lane* from, Lane* to) {
		event_ = car_enter_lane;
		time_ = time;
		car_ = car;
		extra_ = *(new extra_info());
		extra_.from = from;
		extra_.to = to;
	}

	/** Construtor no caso car_enter_queue
	 *  \param time tempo do evento
	 *  \param car carro
	 *  \param current pista atual do carro
	 */
	Event::Event (utility::Simple_time time, Lane* current) {
		event_ = car_enter_queue;
		time_ = time;
		extra_ = *(new extra_info());
		extra_.from = current;
		extra_.to = current;
	}

	/** Construtor no caso light_switch
	 *  \param time tempo do evento
	 */
	Event::Event (utility::Simple_time time) {
		event_ = light_switch;
		time_ = time;
	}

	/** Um evento aconteceu antes do outro?
	 *  \return true se lado esquerdo aconteceu antes do direito
	 */
	bool Event::operator< (const Event other) const {
		return time_ < other.time_;
	}

	/** Representa��o em string do evento.
	 *
	 */
	std::string Event::to_string () {
		std::ostringstream output;
		std::string parts[7];
		output << time_.to_string() << " ";

		switch (event_) {
		case (car_enter_lane):
		{
			std::string from_str, to_str;
			if (extra_.from == nullptr) {
				from_str = "o nada";
			} else {
				from_str = "a pista " + extra_.from->name();
			}
			if (extra_.to == nullptr) {
				to_str = "o nada";
			} else {
				to_str = "a pista " + extra_.to->name();
			}
			output << "Carro " << car_->name() << " vindo d"
					<< from_str << " foi para " << to_str << ".";
			break;
		}
		case (car_enter_queue):
		{
			output << "Carro " << car_->name() << " entrou na sua fila " << extra_.from->name() << ".";
			break;
		}
		case (light_switch):
		{
			output << "Sem�foro mudou a dire��o para " << dir_names[int (Traffic_light::direction())] << ".";
			break;
		}
		default:
		{
			throw "Tipo inv�lido de evento";
			break;
		}
		}
		return output.str();
	}

	/** Realiza o evento.
	 *
	 */
	std::string Event::run () {
		std::ostringstream output;
		switch (event_) {
		{
		case (car_enter_lane):
			if (extra_.from == nullptr) { //se foi spawn
				Spawn* sto = dynamic_cast<Spawn*> (extra_.to);
				sto->createCar();
				utility::Simple_time t = time_ + sto->timeForNewCar();
				Event ev = *(new Event(t, nullptr, nullptr, extra_.to)); //pr�ximo spawn
				push(&ev);
			} else if (extra_.to == nullptr) { //se despawn
				Edge* dfrom = dynamic_cast<Edge*>(extra_.from);
				dfrom->removeCar();

			} else {
				bool fail;
				if (extra_.to->canAdd(car_) &&  extra_.from->get_direction() == Traffic_light::direction()) {
					extra_.from->moveCar(extra_.to);
					utility::Simple_time t = time_ + *(new utility::Simple_time(1000)); //um segundo cada
					Event ev = *(new Event
					(t, extra_.from->frontCar(), extra_.from, extra_.from->choose_lane())); //pr�xima pista pro carro de tr�s
					push(&ev);
				} else {
					output << "Carro n�o conseguiu trocar de pista: ";
					if (extra_.to->canAdd(car_)) {
						output << "sinal vermelho.";
					} else {
						output << "congestionamento!";
					}
					utility::Simple_time t = time_ + *(new utility::Simple_time(2000)); //dois segundos espera
					Event ev = *(new Event(t, car_, extra_.from, extra_.to)); //tentar de novo
					push(&ev);
				}
			}
		break;
		}
		case (car_enter_queue):
		{
			if (car_->expected_queue_size == extra_.from->waitingSize()) {
				extra_.to->pushCar();
				if (extra_.from->waitingSize() == 1) {
					Event ev = *(new Event
					(time_, car_, extra_.from, extra_.from->choose_lane())); //pr�xima pista carro que chegou na frente
					push(&ev);
				}
			} else {
				Event ev = *(new Event(time_ + *(new utility::Simple_time(2000)), extra_.from)); //tenta de novo
			}
			break;
		}
		case (light_switch):
		{
			Traffic_light::changeDirection();
			utility::Simple_time t = *(new utility::Simple_time(Traffic_light::get_period()*1000));
			Event ev = *(new Event(t));
			push(&ev);
			break;
		}
		default:
		{
		throw "Tipo inv�lido de evento";
		}
		}
		return output.str();
	}


	utility::Simple_time Event::get_time () {
		return time_;
	}


	//-----------REL�GIO--------------
	std::string Event::clock_to_string() {
		std::ostringstream output;
		output << "Lista de eventos:\n---------------------------\n"
				<< events.to_string();
		return output.str();
	}

	void Event::push(Event* event) {
		events.insert_sorted(event);
	}

	void Event::step() {
		Event* step = events.pop_back();
		std::cout << step->to_string() << std::endl;
		step->run();
		clock_time_ = step->get_time();
		delete &step;
	}

	utility::Simple_time Event::clock_get_time() {
		return clock_time_;


};

#endif
