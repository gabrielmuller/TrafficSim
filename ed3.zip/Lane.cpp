#ifndef LANE_CPP_
#define LANE_CPP_

#include <iostream>
#include "Car.cpp"
#include "linked_queue.h"
#include "random.h"
#include "Traffic_light.h"

class Lane {
protected:

    direction direction_;
    int* probabilities_;                // [0] right, [1] straight, [2] left
    int velocity_, size_, freeSpace_;

    int totalIn_ = 0, totalOut_ = 0;
    structures::LinkedQueue<Car*> moving_queue, waiting_queue;
    Lane *rightExit, *straightExit, *leftExit;

public:

	Lane* choose_lane() {
		int r = utility::random_range(0, 100);
		Lane* output;
		if (r < probabilities_[0]) {
			output = rightExit;
		} else if (r < probabilities_[0] + probabilities_[1]) {
			output = straightExit;
		} else {
			output = leftExit;
		}
		return output;
	}

    Lane(direction dir, int prob[3], int vel, int size):
            direction_(dir),
            probabilities_(prob),
            velocity_(vel),
            size_(size),
            freeSpace_(size),
            rightExit(nullptr),
            straightExit(nullptr),
            leftExit(nullptr)
        {}

    Lane(direction dir, int prob[3], int vel, int size, Lane* r, Lane* s, Lane* l):
        direction_(dir),
        probabilities_(prob),
        velocity_(vel),
        size_(size),
        freeSpace_(size),
        rightExit(r),
        straightExit(s),
        leftExit(l)
    {}
	virtual ~Lane() {

	}
	void addCar(Car* car) {
		if (!canAdd(car)) {
			throw std::runtime_error("Full lane");
		}

		moving_queue.enqueue(car);
		++totalIn_;
        std::cout << "Carro add" << "\n";
	}

    bool canAdd(Car* car) {
    		return car->size() <= freeSpace_;
    	}

    direction get_direction() {
    	return direction_;
    }

    int waitingSize() {
    	return waiting_queue.size();
    }
    void pushCar() {
        Car* car =  moving_queue.dequeue();
        waiting_queue.enqueue(car);
        freeSpace_ -= car->size();

    }
    Car* removeCar() {
        Car* car = waiting_queue.dequeue();
        freeSpace_ += car->size();
        ++totalOut_;
        return car;
    }

    Car* frontCar() {
        return waiting_queue.front();
    }
    bool empty() {
        return moving_queue.empty();
    }

    std::string name() {
        return "copa pist�o";
    }

    int timeTaken() {
        return size_ / velocity_ / 3.6;
    }

    int freeSpace() {
        return freeSpace_;
    }

    void moveCar(Lane* exit) {
        if (Traffic_light::direction() != direction_) {
            throw std::runtime_error("Sinal vermelho");
        }
        Car* car = removeCar();
        exit->addCar(car);
        std::cout << "Carro moveu" << "\n";
    }
};

class Spawn : public Lane {
private:
    int fixedFreq, varFreq;
public:
    Spawn(direction dir, int prob[3], int vel, int size, int ff, int vf, Lane* r, Lane* s, Lane* l):
        Lane(dir, prob, vel, size, r, s, l),
        fixedFreq(ff - vf), varFreq(2*vf)
    {}

    void createCar() {
        Car* car = new Car();
        addCar(car);
    }

    /*Lane* moveCar() {
        if (Traffic_light::direction() != direction_) {
            throw std::runtime_error("Sinal vermelho");
        }

        auto car = frontCar();

        int r = utility::random_range(0, 100);

        if (r < probabilities_[0]) {
            leftExit->addCar(car);
            return leftExit;
        } else if (r < probabilities_[0] + probabilities_[1]) {
            rightExit->addCar(car);
            return rightExit;
        } else {
            straightExit->addCar(car);
            return straightExit;
        }
    }*/

	utility::Simple_time timeForNewCar() {
		int seconds = utility::random_range(fixedFreq-varFreq, fixedFreq+varFreq);
		return *(new utility::Simple_time(seconds * 1000));
	}
};

/*
 * Central � s� uma Lane normal?
 * class CentralLane : public Lane {
private:
    Lane *rightExit, *straightExit, *leftExit;
public:
    CentralLane(direction dir, int* prob, int vel, int size, Lane* r, Lane* s, Lane* l):
        Lane(dir, prob, vel, size, r, s, l),
        rightExit(r), straightExit(s), leftExit(l)
    {}

    Lane* moveCar() {
        if (Traffic_light::direction() != direction_) {
            throw std::runtime_error("Sinal vermelho");
        }

        auto car = removeCar();

        int r = utility::random_range(0, 100);

        if (r < probabilities_[0]) {
            leftExit->addCar(car);
            return leftExit;
        } else if (r < probabilities_[0] + probabilities_[1]) {
            rightExit->addCar(car);
            return rightExit;
        } else {
            straightExit->addCar(car);
            return straightExit;
        }
    }
};*/

class Edge : public Lane {
public:
    Edge(direction dir, int prob[3], int vel, int size):
        Lane(dir, prob, vel, size)
    {}

    void moveCar() {
        Car* car = removeCar();
        delete car;
    }
};

#endif
