// Copyright [2017] <Gabriel Müller>

#ifndef STRUCTURES_LINKED_QUEUE_H
#define STRUCTURES_LINKED_QUEUE_H

#include <cstdint>
#include <stdexcept>

namespace structures {

template <typename T>

/**
 * Implementação de fila encadeada.
 */
class LinkedQueue {
 public:
  /** Não há declaração de construtor.
   *  Os atributos já são iniciados com os valores corretos.
   */

  /** Destrutor.
   *  Chama o método 'clear' para limpar a fila.
   */
  ~LinkedQueue() { clear(); }

  /** Limpa a fila.
   *  Deleta todos elementos da memória e reinicia os atributos.
   */
  void clear() {
    if (!empty()) {
      Node* prev = head;
      Node* next;
      for (int i = 0; i < size(); i++) {
        next = prev->next();
        delete prev;
        prev = next;
      }
      size_ = 0;
      head = nullptr;
      tail = nullptr;
    }
  }

  /** Adiciona dado à fila.
   *  \param data dado a adicionar.
   */
  void enqueue(const T& data) {
    Node* node = new Node(data);
    if (node == nullptr) {
      throw std::out_of_range("fila cheia");
    }
    if (empty()) {
      head = node;
    } else {
      tail->next(node);
    }
    size_++;
    tail = node;
  }

  /** Remove um dado da fila.
   *  \return dado removido.
   */
  T dequeue() {
    if (empty()) {
      throw std::out_of_range("fila vazia");
    }
    Node* toDequeue = head;
    if (this->size() == 1) {
      head = nullptr;
    } else {
      head = toDequeue->next();
    }
    size_--;
    T output = toDequeue->data();
    delete toDequeue;
    return output;
  }

  /** Dado da frente.
   *  \return dado.
   */
  T& front() const {
    if (empty()) {
      throw std::out_of_range("fila vazia");
    }
    return head->data();
  }

  /** Dado de trás.
   *  \return dado.
   */
  T& back() const {
    if (empty()) {
      throw std::out_of_range("fila vazia");
    }
    return tail->data();
  }

  /** fila vazia?
   *  \return true se vazia.
   */
  bool empty() const { return size_ == 0; }

  /** Tamanho.
   *  \return número de elementos da fila.
   */
  std::size_t size() const { return size_; }

 private:
  class Node {  // Elemento
   public:
    /** Construtor por dado.
     *  \param data dado por referência.
     */
    explicit Node(const T& data) : data_{data} {}

    /** Construtor por dado e próximo elemento.
     *  \param data dado por referência.
     *  \param next próximo elemento no contexto da fila.
     */
    Node(const T& data, Node* next) : data_{data}, next_{next} {}

    /** Dado.
     *  \return dado por referência.
     */
    T& data() {  // getter: dado
      return data_;
    }

    /** Dado para leitura.
     *  \return dado por referência.
     */
    const T& data() const {  // getter const: dado
      return data_;
    }

    /** Próximo elemento.
     *  \return próximo elemento.
     */
    Node* next() {  // getter: próximo
      return next_;
    }

    /** Próximo elemento para leitura.
     *  \return próximo elemento.
     */
    const Node* next() const {  // getter const: próximo
      return next_;
    }

    /** Definir próximo elemento.
     *  \param node próximo elemento.
     */
    void next(Node* node) {  // setter: próximo
      next_ = node;
    }

   private:
    T data_;              /**< Dado do elemento. */
    Node* next_{nullptr}; /**< Próximo elemento. */
  };

  Node* head{nullptr};   // nodo-cabeça
  Node* tail{nullptr};   // nodo-fim
  std::size_t size_{0};  // tamanho
};
}  // namespace structures

#endif
