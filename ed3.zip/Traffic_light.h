#ifndef TRAFFIC_LIGHT_H_
#define TRAFFIC_LIGHT_H_

enum direction {NORTH = 0, SOUTH = 1, EAST = 2, WEST = 3};

class Traffic_light {
private:
    static direction direction_;

public:
    static int get_period();

    static direction direction();

    static void changeDirection();

};

#endif
