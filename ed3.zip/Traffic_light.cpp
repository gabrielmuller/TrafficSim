#ifndef TRAFFIC_LIGHT_CPP_
#define TRAFFIC_LIGHT_CPP_

#include "Traffic_light.h"
#include "array_list.h"

direction Traffic_light::direction_ = EAST;

direction Traffic_light::direction() {
    return direction_;
}

void Traffic_light::changeDirection() {
    switch(direction_) {
        case NORTH: direction_ = EAST; break;
        case EAST: direction_ = SOUTH; break;
        case SOUTH: direction_ = WEST; break;
        case WEST: direction_ = NORTH; break;
    }
}

int Traffic_light::get_period() {
	return 30;
}

#endif
